package com.example.glasshome.data

import android.app.Application
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.glasshome.util.IconLoader
import com.example.glasshome.util.WallpaperLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class HomeViewModel(app: Application) : AndroidViewModel(app) {

    private val store = LayoutStore(app)

    private val _allApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val allApps: StateFlow<List<AppInfo>> = _allApps.asStateFlow()

    private val _pages =
        MutableStateFlow<List<PageRuntime>>(listOf(PageRuntime(5, emptyList())))
    val pages: StateFlow<List<PageRuntime>> = _pages.asStateFlow()

    private val _dock = MutableStateFlow<List<AppInfo>>(emptyList())
    val dock: StateFlow<List<AppInfo>> = _dock.asStateFlow()

    private val _wallpaper = MutableStateFlow<ImageBitmap?>(null)
    val wallpaper: StateFlow<ImageBitmap?> = _wallpaper.asStateFlow()

    private var stored: StoredLayout = StoredLayout()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            val apps = IconLoader.loadAllApps(app)
            val wp = WallpaperLoader.load(app)
            val layout = store.load()
            _allApps.value = apps
            _wallpaper.value = wp
            stored = layout
            applyLayout(layout, apps)
        }
    }

    fun reloadWallpaper() {
        viewModelScope.launch(Dispatchers.IO) {
            _wallpaper.value = WallpaperLoader.load(getApplication())
        }
    }

    fun reloadApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val apps = IconLoader.loadAllApps(getApplication())
            _allApps.value = apps
            applyLayout(stored, apps)
        }
    }

    fun addAppToFirstFree(app: AppInfo) {
        val pagesList = _pages.value.toMutableList()
        var pageIdx = 0
        while (pageIdx < pagesList.size) {
            val page = pagesList[pageIdx]
            if (page.cells.size < 30) break
            pageIdx++
        }
        if (pageIdx == pagesList.size) pagesList.add(PageRuntime(5, emptyList()))
        val page = pagesList[pageIdx]
        val newCell = CellRuntime.AppCell(newCellId(), app)
        pagesList[pageIdx] = page.copy(cells = page.cells + newCell)
        _pages.value = pagesList
        persist()
    }

    fun moveCell(pageIndex: Int, fromIndex: Int, toIndex: Int) {
        val pagesList = _pages.value.toMutableList()
        val page = pagesList.getOrNull(pageIndex) ?: return
        val cells = page.cells.toMutableList()
        if (fromIndex !in cells.indices) return
        val item = cells.removeAt(fromIndex)
        val dest = toIndex.coerceIn(0, cells.size)
        cells.add(dest, item)
        pagesList[pageIndex] = page.copy(cells = cells)
        _pages.value = pagesList
        persist()
    }

    fun createFolder(pageIndex: Int, sourceIdx: Int, targetIdx: Int) {
        val pagesList = _pages.value.toMutableList()
        val page = pagesList.getOrNull(pageIndex) ?: return
        val cells = page.cells.toMutableList()
        if (sourceIdx !in cells.indices || targetIdx !in cells.indices) return
        val a = cells[sourceIdx]
        val b = cells[targetIdx]
        if (a is CellRuntime.AppCell && b is CellRuntime.AppCell) {
            val folder = CellRuntime.FolderCell(
                id = newCellId(),
                apps = listOf(a.app, b.app),
                name = "Folder"
            )
            cells.removeAt(maxOf(sourceIdx, targetIdx))
            cells.removeAt(minOf(sourceIdx, targetIdx))
            cells.add(minOf(sourceIdx, targetIdx).coerceAtMost(cells.size), folder)
            pagesList[pageIndex] = page.copy(cells = cells)
            _pages.value = pagesList
            persist()
        }
    }

    fun removeCell(pageIndex: Int, cellId: String) {
        val pagesList = _pages.value.toMutableList()
        val page = pagesList.getOrNull(pageIndex) ?: return
        pagesList[pageIndex] = page.copy(cells = page.cells.filter { it.id != cellId })
        _pages.value = pagesList
        persist()
    }

    fun addDockApp(app: AppInfo) {
        if (_dock.value.any { it.key == app.key }) return
        _dock.value = _dock.value + app
        persist()
    }

    fun removeDockApp(app: AppInfo) {
        _dock.value = _dock.value.filter { it.key != app.key }
        persist()
    }

    fun openFolderAdd(pageIndex: Int, folderId: String, app: AppInfo) {
        val pagesList = _pages.value.toMutableList()
        val page = pagesList.getOrNull(pageIndex) ?: return
        val cells = page.cells.map { c ->
            if (c is CellRuntime.FolderCell && c.id == folderId) {
                if (c.apps.any { it.key == app.key }) c
                else c.copy(apps = c.apps + app)
            } else c
        }
        pagesList[pageIndex] = page.copy(cells = cells)
        _pages.value = pagesList
        persist()
    }

    fun removeFromFolder(pageIndex: Int, folderId: String, app: AppInfo) {
        val pagesList = _pages.value.toMutableList()
        val page = pagesList.getOrNull(pageIndex) ?: return
        val cells = page.cells.mapNotNull { c ->
            if (c is CellRuntime.FolderCell && c.id == folderId) {
                val remaining = c.apps.filter { it.key != app.key }
                when {
                    remaining.isEmpty() -> null
                    remaining.size == 1 -> CellRuntime.AppCell(newCellId(), remaining.first())
                    else -> c.copy(apps = remaining)
                }
            } else c
        }
        pagesList[pageIndex] = page.copy(cells = cells)
        _pages.value = pagesList
        persist()
    }

    private fun applyLayout(layout: StoredLayout, apps: List<AppInfo>) {
        val byKey = apps.associateBy { it.key }

        val runtimePages = layout.pages.map { sp ->
            val cells = sp.cells.mapNotNull { sc ->
                when (sc.type) {
                    "app" -> {
                        val key = "${sc.packageName}/${sc.activityName}"
                        byKey[key]?.let { CellRuntime.AppCell(sc.id, it) }
                    }
                    "folder" -> {
                        val folderApps = sc.folderApps.mapNotNull { sa ->
                            byKey["${sa.packageName}/${sa.activityName}"]
                        }
                        if (folderApps.isEmpty()) null
                        else CellRuntime.FolderCell(sc.id, folderApps, sc.folderName)
                    }
                    "widget" -> sc.widgetId?.let { CellRuntime.WidgetCell(sc.id, it) }
                    else -> null
                }
            }
            PageRuntime(sp.columns, cells)
        }.ifEmpty { listOf(PageRuntime(5, emptyList())) }

        _pages.value = runtimePages
        _dock.value = layout.dock.mapNotNull {
            byKey["${it.packageName}/${it.activityName}"]
        }
    }

    private fun persist() {
        val storedPages = _pages.value.map { page ->
            StoredPage(page.columns, page.cells.mapNotNull { cell ->
                when (cell) {
                    is CellRuntime.AppCell -> StoredCell(
                        id = cell.id,
                        type = "app",
                        packageName = cell.app.packageName,
                        activityName = cell.app.activityName
                    )
                    is CellRuntime.FolderCell -> StoredCell(
                        id = cell.id,
                        type = "folder",
                        folderName = cell.name,
                        folderApps = cell.apps.map {
                            StoredApp(it.packageName, it.activityName)
                        }
                    )
                    is CellRuntime.WidgetCell -> StoredCell(
                        id = cell.id,
                        type = "widget",
                        widgetId = cell.widgetId
                    )
                }
            })
        }
        val storedDock = _dock.value.map {
            StoredApp(it.packageName, it.activityName)
        }
        stored = StoredLayout(storedPages, storedDock)
        store.save(stored)
    }

    companion object {
        fun factory(app: Application): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T =
                    HomeViewModel(app) as T
            }
    }
}
