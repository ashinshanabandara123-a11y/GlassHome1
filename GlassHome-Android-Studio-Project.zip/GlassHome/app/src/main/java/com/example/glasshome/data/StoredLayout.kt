package com.example.glasshome.data

import kotlinx.serialization.Serializable

@Serializable
data class StoredApp(val packageName: String, val activityName: String)

@Serializable
data class StoredCell(
    val id: String,
    val type: String,
    val packageName: String? = null,
    val activityName: String? = null,
    val folderApps: List<StoredApp> = emptyList(),
    val folderName: String = "Folder",
    val widgetId: Int? = null
)

@Serializable
data class StoredPage(
    val columns: Int = 5,
    val cells: List<StoredCell> = emptyList()
)

@Serializable
data class StoredLayout(
    val pages: List<StoredPage> = listOf(StoredPage()),
    val dock: List<StoredApp> = emptyList()
)
