package com.example.glasshome.data

import android.content.Context
import kotlinx.serialization.json.Json

class LayoutStore(private val context: Context) {

    private val prefs =
        context.getSharedPreferences("glass_home_layout", Context.MODE_PRIVATE)

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    fun load(): StoredLayout {
        val raw = prefs.getString(KEY, null) ?: return StoredLayout()
        return runCatching { json.decodeFromString<StoredLayout>(raw) }
            .getOrElse { StoredLayout() }
    }

    fun save(layout: StoredLayout) {
        prefs.edit()
            .putString(KEY, json.encodeToString(StoredLayout.serializer(), layout))
            .apply()
    }

    companion object {
        private const val KEY = "layout_v1"
    }
}
