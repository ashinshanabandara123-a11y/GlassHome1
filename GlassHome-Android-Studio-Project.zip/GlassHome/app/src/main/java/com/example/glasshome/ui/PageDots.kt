package com.example.glasshome.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun PageDots(current: Int, total: Int, modifier: Modifier = Modifier) {
    if (total <= 1) return
    Row(
        modifier.padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        repeat(total) { i ->
            val active = i == current
            Box(
                Modifier
                    .size(if (active) 8.dp else 6.dp)
                    .background(
                        color = if (active) Color.White
                        else Color.White.copy(alpha = 0.35f),
                        shape = CircleShape
                    )
            )
        }
    }
}
