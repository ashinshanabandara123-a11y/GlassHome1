package com.example.glasshome.data

import android.app.Application
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.glasshome.util.IconLoader
import com.example.glasshome.util.WallpaperLoader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val store = LayoutStore(app)
    private val _allApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val allApps: StateFlow<List<AppInfo>> = _allApps.asStateFlow()
    private val _pages = MutableStateFlow(listOf(PageRuntime(5, emptyList())))
    val pages: StateFlow<List<PageRuntime>> = _pages.asStateFlow()
    private val _dock = MutableStateFlow<List<AppInfo>>(emptyList())
    val dock: StateFlow<List<AppInfo>> = _dock.asStateFlow()
    private val _wallpaper = MutableStateFlow<ImageBitmap?>(null)
    val wallpaper: StateFlow<ImageBitmap?> = _wallpaper.asStateFlow()
    private var stored = StoredLayout()

    init {
        viewModelScope.launch(Dispatchers.IO) {
            val apps = IconLoader.loadAllApps(app)
            val wp = WallpaperLoader.load(app)
            val layout = store.load()
            _allApps.value = apps; _wallpaper.value = wp; stored = layout
            applyLayout(layout, apps)
        }
    }
    fun reloadWallpaper() { viewModelScope.launch(Dispatchers.IO) { _wallpaper.value = WallpaperLoader.load(getApplication()) } }
    fun reloadApps() { viewModelScope.launch(Dispatchers.IO) { val apps = IconLoader.loadAllApps(getApplication()); _allApps.value = apps; applyLayout(stored, apps) } }

    fun addAppToFirstFree(app: AppInfo) {
        val list = _pages.value.toMutableList(); var index = 0
        while (index < list.size && list[index].cells.size >= 30) index++
        if (index == list.size) list.add(PageRuntime(5, emptyList()))
        list[index] = list[index].copy(cells = list[index].cells + CellRuntime.AppCell(newCellId(), app))
        _pages.value = list; persist()
    }
    fun moveCell(pageIndex: Int, fromIndex: Int, toIndex: Int) {
        val list = _pages.value.toMutableList(); val page = list.getOrNull(pageIndex) ?: return
        val cells = page.cells.toMutableList(); if (fromIndex !in cells.indices) return
        val item = cells.removeAt(fromIndex); cells.add(toIndex.coerceIn(0, cells.size), item)
        list[pageIndex] = page.copy(cells = cells); _pages.value = list; persist()
    }
    fun createFolder(pageIndex: Int, sourceIdx: Int, targetIdx: Int) {
        val list = _pages.value.toMutableList(); val page = list.getOrNull(pageIndex) ?: return
        val cells = page.cells.toMutableList(); if (sourceIdx !in cells.indices || targetIdx !in cells.indices) return
        val a = cells[sourceIdx]; val b = cells[targetIdx]
        if (a is CellRuntime.AppCell && b is CellRuntime.AppCell) {
            val at = minOf(sourceIdx, targetIdx)
            val folder = CellRuntime.FolderCell(newCellId(), listOf(a.app, b.app), "Folder")
            cells.removeAt(maxOf(sourceIdx, targetIdx)); cells.removeAt(at); cells.add(at.coerceAtMost(cells.size), folder)
            list[pageIndex] = page.copy(cells = cells); _pages.value = list; persist()
        }
    }
    fun removeCell(pageIndex: Int, cellId: String) {
        val list = _pages.value.toMutableList(); val page = list.getOrNull(pageIndex) ?: return
        list[pageIndex] = page.copy(cells = page.cells.filterNot { it.id == cellId }); _pages.value = list; persist()
    }
    fun addDockApp(app: AppInfo) { if (_dock.value.any { it.key == app.key }) return; _dock.value = _dock.value + app; persist() }
    fun removeDockApp(app: AppInfo) { _dock.value = _dock.value.filterNot { it.key == app.key }; persist() }
    fun openFolderAdd(pageIndex: Int, folderId: String, app: AppInfo) {
        updateFolder(pageIndex, folderId) { f -> if (f.apps.any { it.key == app.key }) f else f.copy(apps = f.apps + app) }
    }
    fun removeFromFolder(pageIndex: Int, folderId: String, app: AppInfo) {
        val list = _pages.value.toMutableList(); val page = list.getOrNull(pageIndex) ?: return
        val cells = page.cells.mapNotNull { c ->
            if (c is CellRuntime.FolderCell && c.id == folderId) {
                val remaining = c.apps.filterNot { it.key == app.key }
                when (remaining.size) { 0 -> null; 1 -> CellRuntime.AppCell(newCellId(), remaining.first()); else -> c.copy(apps = remaining) }
            } else c
        }
        list[pageIndex] = page.copy(cells = cells); _pages.value = list; persist()
    }
    private fun updateFolder(pageIndex: Int, folderId: String, transform: (CellRuntime.FolderCell) -> CellRuntime.FolderCell) {
        val list = _pages.value.toMutableList(); val page = list.getOrNull(pageIndex) ?: return
        list[pageIndex] = page.copy(cells = page.cells.map { if (it is CellRuntime.FolderCell && it.id == folderId) transform(it) else it })
        _pages.value = list; persist()
    }
    private fun applyLayout(layout: StoredLayout, apps: List<AppInfo>) {
        val byKey = apps.associateBy { it.key }
        val runtime = layout.pages.map { storedPage ->
            val cells = storedPage.cells.mapNotNull { cell -> when (cell.type) {
                "app" -> byKey["${cell.packageName}/${cell.activityName}"]?.let { CellRuntime.AppCell(cell.id, it) }
                "folder" -> cell.folderApps.mapNotNull { byKey["${it.packageName}/${it.activityName}"] }.takeIf { it.isNotEmpty() }?.let { CellRuntime.FolderCell(cell.id, it, cell.folderName) }
                "widget" -> cell.widgetId?.let { CellRuntime.WidgetCell(cell.id, it) }
                else -> null
            } }
            PageRuntime(storedPage.columns, cells)
        }.ifEmpty { listOf(PageRuntime(5, emptyList())) }
        _pages.value = runtime; _dock.value = layout.dock.mapNotNull { byKey["${it.packageName}/${it.activityName}"] }
    }
    private fun persist() {
        val pages = _pages.value.map { page -> StoredPage(page.columns, page.cells.map { cell -> when (cell) {
            is CellRuntime.AppCell -> StoredCell(cell.id, "app", cell.app.packageName, cell.app.activityName)
            is CellRuntime.FolderCell -> StoredCell(cell.id, "folder", folderApps = cell.apps.map { StoredApp(it.packageName, it.activityName) }, folderName = cell.name)
            is CellRuntime.WidgetCell -> StoredCell(cell.id, "widget", widgetId = cell.widgetId)
        } }) }
        stored = StoredLayout(pages, _dock.value.map { StoredApp(it.packageName, it.activityName) }); store.save(stored)
    }
    companion object {
        fun factory(app: Application): ViewModelProvider.Factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : androidx.lifecycle.ViewModel> create(modelClass: Class<T>): T = HomeViewModel(app) as T
        }
    }
}
