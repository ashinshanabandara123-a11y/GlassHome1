package com.example.glasshome.ui

import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.glasshome.ui.glass.LiquidGlass

@Composable
fun WidgetHost(
    widgetId: Int,
    wallpaper: ImageBitmap?,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val host = remember { AppWidgetHost(context, HOST_ID) }
    val manager = remember { AppWidgetManager.getInstance(context) }

    LiquidGlass(
        wallpaper = wallpaper,
        modifier = modifier
            .fillMaxWidth()
            .height(160.dp),
        cornerRadius = 24.dp,
        blurRadius = 20.dp,
        tintAlpha = 0.08f
    ) {
        Box(Modifier.fillMaxSize()) {
            val info = manager.getAppWidgetInfo(widgetId)
            if (info != null) {
                AndroidView(
                    factory = { ctx -> host.createView(ctx, widgetId, info) },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

private const val HOST_ID = 0x51EE
