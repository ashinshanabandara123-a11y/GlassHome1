package com.example.glasshome.data

import java.util.UUID

sealed class CellRuntime {
    abstract val id: String
    data class AppCell(override val id: String, val app: AppInfo) : CellRuntime()
    data class FolderCell(override val id: String, val apps: List<AppInfo>, val name: String) : CellRuntime()
    data class WidgetCell(override val id: String, val widgetId: Int) : CellRuntime()
}
data class PageRuntime(val columns: Int, val cells: List<CellRuntime>)
fun newCellId(): String = UUID.randomUUID().toString()
