package com.example.glasshome.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.Drawable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import com.example.glasshome.data.AppInfo

/**
 * The ONLY source of app icons in this launcher.
 *
 * getApplicationIcon returns the icon the system / OEM theme engine
 * already produced for this package. It is not re-masked, re-tinted,
 * re-shaped, or passed through any adaptive-icon transform.
 */
object IconLoader {

    fun loadDefaultIcon(context: Context, packageName: String): ImageBitmap? = try {
        val drawable: Drawable = context.packageManager.getApplicationIcon(packageName)
        val w = drawable.intrinsicWidth.coerceAtLeast(1)
        val h = drawable.intrinsicHeight.coerceAtLeast(1)
        drawable.toBitmap(w, h, Bitmap.Config.ARGB_8888).asImageBitmap()
    } catch (t: Throwable) {
        null
    }

    fun loadAllApps(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolved = pm.queryIntentActivities(intent, 0)
        val out = ArrayList<AppInfo>(resolved.size)
        val seen = HashSet<String>()
        for (ri in resolved) {
            val pkg = ri.activityInfo.packageName
            val act = ri.activityInfo.name
            val key = "$pkg/$act"
            if (!seen.add(key)) continue
            out += AppInfo(
                packageName = pkg,
                activityName = act,
                label = runCatching { ri.loadLabel(pm).toString() }.getOrDefault(pkg),
                icon = loadDefaultIcon(context, pkg)
            )
        }
        return out.sortedBy { it.label.lowercase() }
    }

    fun launch(context: Context, app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            setClassName(app.packageName, app.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        runCatching { context.startActivity(intent) }
    }
}
