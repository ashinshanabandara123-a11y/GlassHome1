package com.example.glasshome

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import com.example.glasshome.data.HomeViewModel
import com.example.glasshome.ui.HomeScreen

class MainActivity : ComponentActivity() {
    private val vm: HomeViewModel by viewModels { HomeViewModel.factory(application) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(color = Color.Black) { HomeScreen(vm) }
            }
        }
    }
}
