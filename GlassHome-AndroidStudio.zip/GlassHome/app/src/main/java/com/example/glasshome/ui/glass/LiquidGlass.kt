package com.example.glasshome.ui.glass

import android.graphics.Shader
import android.graphics.RenderEffect
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun LiquidGlass(wallpaper: ImageBitmap?, modifier: Modifier = Modifier, cornerRadius: Dp = 24.dp, blurRadius: Dp = 24.dp, tintAlpha: Float = 0.12f, borderAlpha: Float = 0.18f, content: @Composable BoxScope.() -> Unit) {
    val blurPx = with(LocalDensity.current) { blurRadius.toPx() }
    val shape = RoundedCornerShape(cornerRadius)
    Box(modifier.clip(shape)) {
        if (wallpaper != null) {
            val blurMod = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) Modifier.graphicsLayer {
                renderEffect = RenderEffect.createBlurEffect(blurPx, blurPx, Shader.TileMode.CLAMP).asComposeRenderEffect()
            } else Modifier
            Image(wallpaper, null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize().then(blurMod))
        }
        Box(Modifier.matchParentSize().background(Color.White.copy(alpha = tintAlpha)))
        Box(Modifier.matchParentSize().border(1.dp, Color.White.copy(alpha = borderAlpha), shape))
        content()
    }
}
