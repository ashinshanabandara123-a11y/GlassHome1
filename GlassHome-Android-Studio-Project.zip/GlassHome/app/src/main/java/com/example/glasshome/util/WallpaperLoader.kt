package com.example.glasshome.util

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

object WallpaperLoader {

    fun load(context: Context): ImageBitmap? = try {
        val wm = WallpaperManager.getInstance(context)
        val drawable = wm.drawable ?: return null
        val w = drawable.intrinsicWidth.coerceAtLeast(1)
        val h = drawable.intrinsicHeight.coerceAtLeast(1)
        drawable.toBitmap(w, h, Bitmap.Config.ARGB_8888).asImageBitmap()
    } catch (t: Throwable) {
        null
    }
}
