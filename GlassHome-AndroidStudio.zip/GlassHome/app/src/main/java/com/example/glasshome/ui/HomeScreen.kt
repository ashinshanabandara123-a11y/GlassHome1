package com.example.glasshome.ui

import android.app.WallpaperManager
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.glasshome.data.CellRuntime
import com.example.glasshome.data.HomeViewModel
import com.example.glasshome.util.IconLoader

@Composable fun HomeScreen(vm: HomeViewModel) {
    val context = LocalContext.current
    val wallpaper by vm.wallpaper.collectAsState(); val pages by vm.pages.collectAsState()
    val dock by vm.dock.collectAsState(); val allApps by vm.allApps.collectAsState()
    var drawerOpen by remember { mutableStateOf(false) }; var openFolderId by remember { mutableStateOf<String?>(null) }
    var dragAccum by remember { mutableStateOf(0f) }
    val wpLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { vm.reloadWallpaper() }
    LaunchedEffect(Unit) { vm.reloadApps() }
    Box(Modifier.fillMaxSize().pointerInput(Unit) {
        detectVerticalDragGestures(onDragStart = { dragAccum = 0f }, onDragEnd = { if (dragAccum < -180f) drawerOpen = true; dragAccum = 0f }) { _, delta -> dragAccum += delta }
    }) {
        Wallpaper(wallpaper, Modifier.fillMaxSize())
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Workspace(pages, wallpaper, Modifier.weight(1f), onAppClick = { IconLoader.launch(context, it) }, onAppLongClick = { _, cell -> vm.addDockApp(cell.app) }, onFolderClick = { _, folder -> openFolderId = folder.id })
            Dock(dock, wallpaper, Modifier.padding(horizontal = 24.dp, vertical = 16.dp), onAppClick = { IconLoader.launch(context, it) }, onAppLongClick = { vm.removeDockApp(it) })
        }
        AppDrawer(drawerOpen, allApps, wallpaper, onDismiss = { drawerOpen = false }, onAppClick = { IconLoader.launch(context, it) })
        openFolderId?.let { id ->
            val folder = pages.asSequence().flatMap { it.cells.asSequence() }.filterIsInstance<CellRuntime.FolderCell>().firstOrNull { it.id == id }
            if (folder != null) FolderPopup(folder.name, folder.apps, wallpaper, onDismiss = { openFolderId = null }, onAppClick = { IconLoader.launch(context, it) }) else openFolderId = null
        }
        Box(Modifier.align(Alignment.TopEnd).systemBarsPadding().padding(8.dp).pointerInput(Unit) {
            androidx.compose.foundation.gestures.detectTapGestures(onLongPress = { runCatching { wpLauncher.launch(Intent(WallpaperManager.ACTION_SET_WALLPAPER)) } })
        }.then(Modifier.fillMaxSize(.001f)))
    }
}
