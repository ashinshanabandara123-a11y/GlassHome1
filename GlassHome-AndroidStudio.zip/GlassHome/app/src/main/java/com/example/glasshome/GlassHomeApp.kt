package com.example.glasshome

import android.app.Application
import android.content.Context

class GlassHomeApp : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
    }
    companion object {
        lateinit var instance: GlassHomeApp
            private set
        val context: Context get() = instance.applicationContext
    }
}
