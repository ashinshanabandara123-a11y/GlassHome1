# Glass Home

Android Studio project for the Glass Home launcher.

## Build

1. Open this folder (`GlassHome`) in Android Studio.
2. Install Android SDK Platform 35 and Android SDK Build-Tools 35.x.
3. Use JDK 17 when prompted and allow Gradle sync to finish.
4. Build with **Build → Make Project**, or run `gradle :app:assembleDebug` from an environment with Gradle installed.
5. Install `app/build/outputs/apk/debug/app-debug.apk` and choose **Glass Home** as the default Home app.

## Configuration

- Kotlin 1.9.24, Android Gradle Plugin 8.5.2
- Compose compiler extension 1.5.14 (the compatible compiler for Kotlin 1.9.24)
- Compose BOM 2024.09.03
- minSdk 26 / targetSdk 35

Application icons are loaded only by `IconLoader.loadDefaultIcon()` using `PackageManager.getApplicationIcon()`. The launcher UI draws the resulting bitmap without clipping, tinting, masking, or adaptive-icon reconstruction.

## Current scope

Home workspace, app drawer, folders, dock, wallpaper display/picker entry point, and persisted layout data. This initial project does not include lock-screen functionality or a complete widget-picker/allocation flow.
