package com.example.glasshome.ui

import android.app.WallpaperManager
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.glasshome.data.CellRuntime
import com.example.glasshome.data.HomeViewModel
import com.example.glasshome.util.IconLoader

@Composable
fun HomeScreen(vm: HomeViewModel) {
    val context = LocalContext.current
    val wallpaper by vm.wallpaper.collectAsState()
    val pages by vm.pages.collectAsState()
    val dock by vm.dock.collectAsState()
    val allApps by vm.allApps.collectAsState()

    var drawerOpen by remember { mutableStateOf(false) }
    var openFolderId by remember { mutableStateOf<String?>(null) }
    var dragAccum by remember { mutableStateOf(0f) }

    val wpLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        vm.reloadWallpaper()
    }

    LaunchedEffect(Unit) {
        vm.reloadApps()
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { dragAccum = 0f },
                    onDragEnd = {
                        if (dragAccum < -180f) drawerOpen = true
                        dragAccum = 0f
                    }
                ) { _, delta ->
                    dragAccum += delta
                }
            }
    ) {
        Wallpaper(wallpaper, Modifier.fillMaxSize())

        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Workspace(
                pages = pages,
                wallpaper = wallpaper,
                modifier = Modifier.weight(1f),
                onAppClick = { app -> IconLoader.launch(context, app) },
                onAppLongClick = { _, cell -> vm.addDockApp(cell.app) },
                onFolderClick = { _, folder -> openFolderId = folder.id }
            )

            Dock(
                apps = dock,
                wallpaper = wallpaper,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
                onAppClick = { app -> IconLoader.launch(context, app) },
                onAppLongClick = { app -> vm.removeDockApp(app) }
            )
        }

        AppDrawer(
            visible = drawerOpen,
            allApps = allApps,
            wallpaper = wallpaper,
            onDismiss = { drawerOpen = false },
            onAppClick = { app -> IconLoader.launch(context, app) }
        )

        openFolderId?.let { folderId ->
            val folder = pages.asSequence()
                .flatMap { it.cells.asSequence() }
                .filterIsInstance<CellRuntime.FolderCell>()
                .firstOrNull { it.id == folderId }
            if (folder != null) {
                FolderPopup(
                    name = folder.name,
                    apps = folder.apps,
                    wallpaper = wallpaper,
                    onDismiss = { openFolderId = null },
                    onAppClick = { app -> IconLoader.launch(context, app) }
                )
            } else {
                openFolderId = null
            }
        }

        // Long-press top-right corner → launch wallpaper picker.
        Box(
            Modifier
                .align(Alignment.TopEnd)
                .systemBarsPadding()
                .padding(8.dp)
                .size(48.dp)
                .pointerInput(Unit) {
                    detectTapGestures(
                        onLongPress = {
                            runCatching {
                                wpLauncher.launch(
                                    Intent("android.intent.action.SET_WALLPAPER")
                                )
                            }
                        }
                    )
                }
        )
    }
}
