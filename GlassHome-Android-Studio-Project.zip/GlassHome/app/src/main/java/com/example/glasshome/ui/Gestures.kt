package com.example.glasshome.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.Modifier

/**
 * Uniform click / long-click handler used by every interactive surface
 * in the launcher. Wraps combinedClickable so no per-file opt-in is
 * scattered through the UI tree.
 */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.appClickable(
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null
): Modifier = this.combinedClickable(
    onClick = onClick,
    onLongClick = onLongClick
)
