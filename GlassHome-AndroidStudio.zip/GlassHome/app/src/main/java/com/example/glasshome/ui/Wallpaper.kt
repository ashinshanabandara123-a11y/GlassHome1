package com.example.glasshome.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale

@Composable fun Wallpaper(bitmap: ImageBitmap?, modifier: Modifier = Modifier) {
    if (bitmap != null) Image(bitmap, null, contentScale = ContentScale.Crop, modifier = modifier.fillMaxSize())
    else Box(modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1a1a2e), Color(0xFF0f0f1a), Color(0xFF05050a)))))
}
