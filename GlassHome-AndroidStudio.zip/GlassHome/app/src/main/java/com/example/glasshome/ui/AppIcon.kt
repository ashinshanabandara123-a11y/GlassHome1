package com.example.glasshome.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.glasshome.data.AppInfo

@Composable fun AppIcon(app: AppInfo, modifier: Modifier = Modifier, onClick: () -> Unit, onLongClick: () -> Unit = {}) {
    Column(modifier.clickable(interactionSource = MutableInteractionSource(), indication = null, onClick = onClick).pointerInput(Unit) { detectTapGestures(onLongPress = { onLongClick() }) }, horizontalAlignment = Alignment.CenterHorizontally) {
        if (app.icon != null) Image(app.icon, app.label, modifier = Modifier.size(60.dp))
        Spacer(Modifier.height(4.dp))
        Text(app.label, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
