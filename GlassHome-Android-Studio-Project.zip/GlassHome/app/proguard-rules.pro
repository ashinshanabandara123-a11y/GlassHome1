# Default rules. Nothing custom required for debug builds.
