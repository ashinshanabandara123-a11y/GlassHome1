package com.example.glasshome.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.glasshome.data.AppInfo
import com.example.glasshome.ui.glass.LiquidGlass

@Composable fun FolderPopup(name: String, apps: List<AppInfo>, wallpaper: ImageBitmap?, onDismiss: () -> Unit, onAppClick: (AppInfo) -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        LiquidGlass(wallpaper, Modifier.fillMaxWidth().height(380.dp), cornerRadius = 32.dp, blurRadius = 36.dp, tintAlpha = .20f) {
            Column(Modifier.fillMaxSize().padding(20.dp)) {
                Text(name, color = Color.White, fontSize = 20.sp); Spacer(Modifier.height(16.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(4), verticalArrangement = Arrangement.spacedBy(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                    items(apps, key = { it.key }) { app ->
                        Column(Modifier.width(64.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            if (app.icon != null) Image(app.icon, app.label, Modifier.size(52.dp).clickable(interactionSource = MutableInteractionSource(), indication = null) { onAppClick(app) })
                            Spacer(Modifier.height(4.dp)); Text(app.label, color = Color.White, fontSize = 10.sp, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}
