package com.example.glasshome.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.unit.dp
import com.example.glasshome.data.AppInfo
import com.example.glasshome.ui.glass.LiquidGlass

@Composable
fun Dock(
    apps: List<AppInfo>,
    wallpaper: ImageBitmap?,
    modifier: Modifier = Modifier,
    onAppClick: (AppInfo) -> Unit,
    onAppLongClick: (AppInfo) -> Unit = {}
) {
    LiquidGlass(
        wallpaper = wallpaper,
        modifier = modifier
            .fillMaxWidth()
            .height(88.dp),
        cornerRadius = 32.dp,
        blurRadius = 28.dp,
        tintAlpha = 0.14f
    ) {
        Row(
            Modifier.fillMaxSize().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            apps.forEach { app ->
                if (app.icon != null) {
                    Image(
                        bitmap = app.icon,
                        contentDescription = app.label,
                        modifier = Modifier
                            .size(56.dp)
                            .appClickable(
                                onClick = { onAppClick(app) },
                                onLongClick = { onAppLongClick(app) }
                            )
                    )
                }
            }
        }
    }
}
