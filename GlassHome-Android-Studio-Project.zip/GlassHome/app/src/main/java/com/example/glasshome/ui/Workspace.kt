package com.example.glasshome.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.glasshome.data.AppInfo
import com.example.glasshome.data.CellRuntime
import com.example.glasshome.data.PageRuntime
import com.example.glasshome.ui.glass.LiquidGlass

@Composable
fun Workspace(
    pages: List<PageRuntime>,
    wallpaper: ImageBitmap?,
    modifier: Modifier = Modifier,
    onAppClick: (AppInfo) -> Unit,
    onAppLongClick: (Int, CellRuntime.AppCell) -> Unit,
    onFolderClick: (Int, CellRuntime.FolderCell) -> Unit
) {
    val pagerState = rememberPagerState(
        pageCount = { pages.size.coerceAtLeast(1) }
    )

    Column(modifier.fillMaxSize()) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f)
        ) { pageIndex ->
            val page = pages.getOrNull(pageIndex) ?: return@HorizontalPager
            LazyVerticalGrid(
                columns = GridCells.Fixed(page.columns),
                contentPadding = PaddingValues(
                    horizontal = 16.dp,
                    vertical = 24.dp
                ),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(page.cells, key = { it.id }) { cell ->
                    when (cell) {
                        is CellRuntime.AppCell -> AppIcon(
                            app = cell.app,
                            onClick = { onAppClick(cell.app) },
                            onLongClick = { onAppLongClick(pageIndex, cell) }
                        )
                        is CellRuntime.FolderCell -> FolderIcon(
                            folder = cell,
                            onClick = { onFolderClick(pageIndex, cell) }
                        )
                        is CellRuntime.WidgetCell -> WidgetHost(
                            widgetId = cell.widgetId,
                            wallpaper = wallpaper
                        )
                    }
                }
            }
        }

        PageDots(
            current = pagerState.currentPage,
            total = pages.size,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
    }
}

@Composable
private fun FolderIcon(
    folder: CellRuntime.FolderCell,
    onClick: () -> Unit
) {
    LiquidGlass(
        wallpaper = null,
        modifier = Modifier.size(68.dp),
        cornerRadius = 18.dp,
        blurRadius = 0.dp,
        tintAlpha = 0.20f
    ) {
        Column(
            Modifier.fillMaxSize().clickable { onClick() },
            verticalArrangement = Arrangement.spacedBy(2.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                Modifier.fillMaxWidth().padding(6.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                val preview = folder.apps.take(4)
                preview.chunked(2).forEach { rowApps ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        rowApps.forEach { app ->
                            if (app.icon != null) {
                                Image(
                                    bitmap = app.icon,
                                    contentDescription = null,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
            Text(
                text = folder.name,
                color = Color.White,
                fontSize = 9.sp,
                maxLines = 1
            )
        }
    }
}
